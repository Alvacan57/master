export class AgregarCalificacionModels{
    calificacionValor:string;
    criterioCalificacion_Id:string;
    equipo_Id:string;
    usuarioLogin_Id: string;
}