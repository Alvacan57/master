export interface Usuario {
    usuarioLoginId: string;
    usuarioLoginNombre: string;
    usuarioLoginContraseña: string;
    usuarioRol_Id: string;
  }