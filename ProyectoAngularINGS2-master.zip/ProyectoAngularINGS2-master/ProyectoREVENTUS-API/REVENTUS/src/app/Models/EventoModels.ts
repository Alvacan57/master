export class AgregarEventoModels{
    eventoNombre:string;
    eventoFecha:string;
    catalogoEstado_Id:string;
}