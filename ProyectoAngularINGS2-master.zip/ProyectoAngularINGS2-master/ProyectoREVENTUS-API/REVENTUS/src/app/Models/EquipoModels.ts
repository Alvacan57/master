export class AgregarEquipoModels{
    equipopNombre:string;
    evento_Id:string;
}