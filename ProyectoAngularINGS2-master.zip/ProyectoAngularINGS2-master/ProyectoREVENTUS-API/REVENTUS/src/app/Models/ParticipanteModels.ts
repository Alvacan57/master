export class AgregarPaticipanteModels{
    participanteNombre:string;
    carrera_Id:string;
    equipo_Id:string;
}