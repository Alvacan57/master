export class AgregarCriterioModels{
    criterioCalificacionNombre:string;
    evento_Id:string;
}